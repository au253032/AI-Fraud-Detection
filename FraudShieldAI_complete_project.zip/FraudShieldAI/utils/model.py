import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from utils.config import FEATURES, MODEL_DIR, MODEL_FILE
from utils.data import make_demo_data

def train_demo_model():
    """Train on synthetic demonstration data, not real customer data."""
    df = make_demo_data(n=12000, seed=17)
    X = df[FEATURES]
    y = df["is_fraud"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", RandomForestClassifier(
            n_estimators=180, class_weight="balanced",
            random_state=42, min_samples_leaf=2, n_jobs=-1
        )),
    ])
    model.fit(X_train, y_train)
    probabilities = model.predict_proba(X_test)[:, 1]
    predictions = (probabilities >= 0.5).astype(int)
    metrics = {
        "roc_auc": float(roc_auc_score(y_test, probabilities)),
        "report": classification_report(y_test, predictions, zero_division=0, output_dict=True),
        "confusion_matrix": confusion_matrix(y_test, predictions).tolist(),
        "test_rows": int(len(y_test)),
    }
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "features": FEATURES, "metrics": metrics}, MODEL_FILE)
    return metrics

def load_model():
    if not MODEL_FILE.exists():
        return None
    try:
        return joblib.load(MODEL_FILE)
    except Exception:
        return None

def predict_one(model_bundle, row):
    X = pd.DataFrame([{f: row[f] for f in FEATURES}], columns=FEATURES)
    probability = float(model_bundle["model"].predict_proba(X)[0, 1])
    return probability
