from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
TRANSACTIONS_FILE = DATA_DIR / "transactions.csv"
MODEL_FILE = MODEL_DIR / "fraud_model.pkl"

FEATURES = [
    "amount",
    "hour",
    "is_new_device",
    "location_mismatch",
    "tx_count_1h",
    "avg_amount_ratio",
    "failed_logins",
]
