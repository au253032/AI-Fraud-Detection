import streamlit as st

def page_header(title, subtitle):
    st.title(title)
    st.caption(subtitle)

def risk_label(score):
    if score >= 0.70:
        return "High"
    if score >= 0.35:
        return "Medium"
    return "Low"

def risk_color(score):
    if score >= 0.70:
        return "🔴"
    if score >= 0.35:
        return "🟠"
    return "🟢"
