import numpy as np
import pandas as pd
from utils.config import DATA_DIR, TRANSACTIONS_FILE, FEATURES

def make_demo_data(n=2500, seed=42):
    """Create clearly synthetic transactions for a safe demonstration."""
    rng = np.random.default_rng(seed)
    amount = np.clip(rng.lognormal(mean=3.7, sigma=1.0, size=n), 1, 20000)
    hour = rng.integers(0, 24, n)
    is_new_device = rng.binomial(1, 0.12, n)
    location_mismatch = rng.binomial(1, 0.08, n)
    tx_count_1h = np.clip(rng.poisson(1.5, n), 0, 15)
    avg_amount_ratio = np.clip(rng.lognormal(0, 0.7, n), 0.1, 20)
    failed_logins = np.clip(rng.poisson(0.15, n), 0, 8)

    # Synthetic label rule with noise. This is not a real banking fraud model.
    raw = (
        0.00010 * amount
        + 1.25 * is_new_device
        + 1.65 * location_mismatch
        + 0.12 * tx_count_1h
        + 0.35 * np.maximum(avg_amount_ratio - 2, 0)
        + 0.30 * failed_logins
        + 0.35 * (hour <= 4)
        - 2.0
    )
    probability = 1 / (1 + np.exp(-raw))
    probability = np.clip(probability * 0.12, 0.005, 0.35)
    fraud = rng.binomial(1, probability)

    df = pd.DataFrame({
        "transaction_id": [f"TXN{i:06d}" for i in range(1, n + 1)],
        "customer_id": [f"CUST{rng.integers(1000, 9999)}" for _ in range(n)],
        "amount": amount.round(2),
        "hour": hour,
        "is_new_device": is_new_device,
        "location_mismatch": location_mismatch,
        "tx_count_1h": tx_count_1h,
        "avg_amount_ratio": avg_amount_ratio.round(2),
        "failed_logins": failed_logins,
        "location": rng.choice(["Karachi", "Lahore", "Islamabad", "Dubai", "London"], n),
        "status": "Approved",
        "is_fraud": fraud,
    })
    df.loc[df["is_fraud"] == 1, "status"] = "Flagged"
    return df

def ensure_demo_data():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not TRANSACTIONS_FILE.exists():
        make_demo_data().to_csv(TRANSACTIONS_FILE, index=False)
    return pd.read_csv(TRANSACTIONS_FILE)

def load_transactions():
    if not TRANSACTIONS_FILE.exists():
        return ensure_demo_data()
    try:
        return pd.read_csv(TRANSACTIONS_FILE)
    except Exception:
        return ensure_demo_data()

def save_transactions(df):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(TRANSACTIONS_FILE, index=False)

def get_feature_frame(row):
    return pd.DataFrame([{feature: row[feature] for feature in FEATURES}], columns=FEATURES)
